package com;

import model.Supplier;

//For REST Service
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
//For JSON
import com.google.gson.*;
//For XML
import org.jsoup.*;
import org.jsoup.parser.*;
import org.jsoup.nodes.Document;

@Path("/Suppliers")

public class SupplierService {
	

	Supplier supplierObj = new Supplier();

	@GET
	@Path("/")
	@Produces(MediaType.TEXT_HTML)
	public String readSuppliers() {
		return supplierObj.readSuppliers();
	}

	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String insertSupplier(@FormParam("supAccNo") String supAccNo, @FormParam("supUnitPrice") String supUnitPrice,
			@FormParam("supStartDate") String supStartDate, @FormParam("supLastDate") String supLastDate) {
		String output = supplierObj.insertSupplier(supAccNo, supUnitPrice, supStartDate, supLastDate);
		return output;
	}

	@PUT
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String updateSupplier(String supplierData) {
		// Convert the input string to a JSON object
		JsonObject supplierObject = new JsonParser().parse(supplierData).getAsJsonObject();
		// Read the values from the JSON object
		String supID = supplierObject.get("supID").getAsString();
		String supAccNo = supplierObject.get("supAccNo").getAsString();
		String supUnitPrice = supplierObject.get("supUnitPrice").getAsString();
		String supStartDate = supplierObject.get("supStartDate").getAsString();
		String supLastDate = supplierObject.get("supLastDate").getAsString();
		String output = supplierObj.updateSupplier(supID, supAccNo, supUnitPrice, supStartDate, supLastDate);
		return output;
	}

	@DELETE
	@Path("/")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public String deleteSupplier(String supplierData) {
		// Convert the input string to an XML document
		Document doc = Jsoup.parse(supplierData, "", Parser.xmlParser());

		// Read the value from the element <itemID>
		String supID = doc.select("supID").text();
		String output = supplierObj.deleteSupplier(supID);
		return output;
	}

}