package model;

import java.sql.*;

public class Supplier {

	// A common method to connect to the DB
	private Connection connect() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			// Provide the correct details: DBServer/DBName, username, password
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/supplier2", "root", "isuru12345");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public String insertSupplier(String accNo, String unitPrice, String startDate, String lastDate) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for inserting.";
			}
			// create a prepared statement
			String query = " insert into suppliers (`supID`,`supAccNo`,`supUnitPrice`,`supStartDate`,`supLastDate`)"
					+ " values (?, ?, ?, ?, ?)";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setInt(1, 0);
			preparedStmt.setString(2, accNo);
			preparedStmt.setString(3, unitPrice);
			preparedStmt.setString(4, startDate);
			preparedStmt.setString(5, lastDate);
			preparedStmt.execute();
			con.close();
			output = "Inserted successfully";
		} catch (Exception e) {
			output = "Error while inserting the supplier.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String readSuppliers() {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for reading.";
			}
			// Prepare the html table to be displayed
			output = "<table border='1'><tr><th>Acc No</th><th>Unit Price</th>" + "<th>Start Date</th>"
					+ "<th>Last Date</th>" + "<th>Update</th><th>Remove</th></tr>";

			String query = "select * from suppliers";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			// iterate through the rows in the result set
			while (rs.next()) {
				String supID = Integer.toString(rs.getInt("supID"));
				String supAccNo = rs.getString("supAccNo");
				String supUnitPrice = rs.getString("supUnitPrice");
				String supStartDate = rs.getString("supStartDate");
				String supLastDate = rs.getString("supLastDate");
				// Add into the html table
				output += "<tr><td>" + supAccNo + "</td>";
				output += "<td>" + supUnitPrice + "</td>";
				output += "<td>" + supStartDate + "</td>";
				output += "<td>" + supLastDate + "</td>";
				// buttons
				output += "<td><input name='btnUpdate' type='button' value='Update' class='btn btn-secondary'></td>"
						+ "<td><form method='post' action='suppliers.jsp'>"
						+ "<input name='btnRemove' type='submit' value='Remove' class='btn btn-danger'>"
						+ "<input name='intID' type='hidden' value='" + supID + "'>" + "</form></td></tr>";
			}
			con.close();
			// Complete the html table
			output += "</table>";
		} catch (Exception e) {
			output = "Error while reading the suppliers.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String updateSupplier(String ID, String accNo, String unitPrice, String startDate, String lastDate) {

		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for updating.";
			}
			// create a prepared statement
			String query = "UPDATE suppliers SET supAccNo=?,supUnitPrice=?,supStartDate=?,supLastDate=? WHERE supID=?";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setString(1, accNo);
			preparedStmt.setString(2, unitPrice);
			preparedStmt.setString(3, startDate);
			preparedStmt.setString(4, lastDate);
			preparedStmt.setInt(5, Integer.parseInt(ID));
			// execute the statement
			preparedStmt.execute();
			con.close();
			output = "Updated successfully";
		} catch (Exception e) {
			output = "Error while updating the supplier.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String deleteSupplier(String supID) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for deleting.";
			}
			// create a prepared statement
			String query = "delete from suppliers where supID=?";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setInt(1, Integer.parseInt(supID));
			// execute the statement
			preparedStmt.execute();
			con.close();
			output = "Deleted successfully";
		} catch (Exception e) {
			output = "Error while deleting the supplier.";
			System.err.println(e.getMessage());
		}
		return output;
	}

}
